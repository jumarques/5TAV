package ViewModel;
import ViewModel.Produto;
public class ProdutoViewModel extends Produto {

	public ProdutoViewModel(int codprod, String produto, String empresa, float preco, String tipo) {
		super(codprod, produto, empresa, preco, tipo);
		// TODO Auto-generated constructor stub
		
	}

}
