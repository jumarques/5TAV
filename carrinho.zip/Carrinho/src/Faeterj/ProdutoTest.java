package Faeterj;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ProdutoTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCodprod() {
		fail("Not yet implemented");
	}

	@Test
	void testSetCodprod() {
		fail("Not yet implemented");
	}

	@Test
	void testGetProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testSetProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testGetEmpresa() {
		fail("Not yet implemented");
	}

	@Test
	void testSetEmpresa() {
		fail("Not yet implemented");
	}

	@Test
	void testGetPreco() {
		fail("Not yet implemented");
	}

	@Test
	void testSetPreco() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTipo() {
		fail("Not yet implemented");
	}

	@Test
	void testSetTipo() {
		fail("Not yet implemented");
	}

	@Test
	void testInserirProduto() {
		fail("Not yet implemented");
	}

	@Test
	void testObject() {
		fail("Not yet implemented");
	}

	@Test
	void testGetClass() {
		fail("Not yet implemented");
	}

	@Test
	void testHashCode() {
		fail("Not yet implemented");
	}

	@Test
	void testEquals() {
		fail("Not yet implemented");
	}

	@Test
	void testClone() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testNotify() {
		fail("Not yet implemented");
	}

	@Test
	void testNotifyAll() {
		fail("Not yet implemented");
	}

	@Test
	void testWaitLong() {
		fail("Not yet implemented");
	}

	@Test
	void testWaitLongInt() {
		fail("Not yet implemented");
	}

	@Test
	void testWait() {
		fail("Not yet implemented");
	}

	@Test
	void testFinalize() {
		fail("Not yet implemented");
	}

}
