public class Calcular {
public double a;
public double b;
public double getA() {
	return a;
}

public void setA(double a) {
	this.a = a;
}
public double getB() {
	return b;
}

public void setB(double b) {
	this.b = b;
}
public double Soma(double a, double b) 
{
    return a + b;
}
public double subtrair (double a, double b)
{
	return a - b;
}
public double dividir (double a, double b)
{
	/*try {
        Console.WriteLine(number1 / number2);
     }
     catch (DivideByZeroException) {
        Console.WriteLine("Division of {0} by zero.", number1);
     }*/
}
public double multiplicar (double a, double b)
{
	return a*b;
}
}
